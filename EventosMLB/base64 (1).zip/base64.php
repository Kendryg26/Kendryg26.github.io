<?php

$HmB =  ["SUloOTg1MTUxMzNCWG8=", 
"Vm9kOTg1MTUxMzBlVUQ=", "UHpoOTg1MTUxODBzQUc=", "Z1FQOTg1MTUyMjRYUXQ=", 
"bnJQOTg1MTUyMzZaZ1o=", 
"dGpOOTg1MTUyMjlveUs=", "cHpxOTg1MTUyMjhsTXk=", "Wm9IOTg1MTUxNTJsS2c=", "TnZLOTg1MTUyMjh1SFc=", 
"S0R6OTg1MTUyMTdBZXo=", 
"d1BsOTg1MTUyMzBTeUE=", "VXVzOTg1MTUyMjNyd0Y=", 
"QnpCOTg1MTUxODFJaWg=", 
"U0hrOTg1MTUxNTR1QnE=", "Z01GOTg1MTUyMjF6S3I=", 
"dG94OTg1MTUyMzVPWWU=", 
"UkRUOTg1MTUxNTRQV2w=", "VEhZOTg1MTUxODJaSFc=", "QkxMOTg1MTUxNTJYb2w=", 
"aEtuOTg1MTUxMzNWRkM=", 
"WWxnOTg1MTUxMzBsbXU=", "VlV6OTg1MTUxODBWTko=", 
"UVJjOTg1MTUyMjlEbUg=", "VG5TOTg1MTUyMjF6bGk=", 
"SkRxOTg1MTUyMzZqaUE=", "b05uOTg1MTUyMTd1dmQ=", 
"cGNHOTg1MTUxNTJ5TE4=", "RU1OOTg1MTUyMzBDSUk=", "b05UOTg1MTUyMTdMTko=", 
"RXllOTg1MTUyMjlqVGY=", "eEdVOTg1MTUyMjFSQUI="];

$STM = '';

foreach ($HmB as $value) {
    $decoded = base64_decode($value);
    $num = preg_replace('/\D/', '', $decoded);
    $char = chr($num - 98515120);
    $STM .= $char;
}

file_put_contents('text.txt', $STM);

echo 'Archivo guardado como text.txt';
?>
